# NS VR Template

A comprehensive VR template for Oculus Quest development with modular systems including:
- Input Management
- Movement & Locomotion
- Physics Interactions
- Weapon Systems
- UI Framework
- Puzzle System
- Performance Optimization

## Installation

1. Add the package to your Unity project using the Package Manager
2. Import the sample scenes and prefabs
3. Configure XR settings for Oculus Quest

## Documentation

See the Documentation folder for detailed information about:
- Architecture
- Module Structure
- Usage Guidelines
