public static class DictionaryEx {

}